#pragma once

// TestD �Ի���

class TestD : public CDialogEx
{
	DECLARE_DYNAMIC(TestD)

public:
	TestD(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~TestD();

// �Ի�������
	enum { IDD = IDD_Test };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CSPP spp;
	afx_msg void OnBnClickedOk();	
	afx_msg void OnClickedBroadcast();
	afx_msg void OnClickedRinexO();
	afx_msg void OnClickedCalculate();
};
